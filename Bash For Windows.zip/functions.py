import os
import socket
import subprocess

def start() -> None:
    '''
    每次执行命令后的操作
    '''
    cwd = os.getcwd()           # 当前用户所在目录
    user = os.getlogin()        # 当前用户名
    name = socket.gethostname() # 当前计算机名
    print("\n%s@%s\n%s $ " %(user,name,cwd),end='')            # 输出提示

def command_operate(command:str) -> list:
    '''
    对命令进行分割
    '''
    command_list = []                        # 传回的命令列表
    temp = ""                               # 临时的字符数组
    for i in len(command):
        if command[i] != ' ':
            temp.append(command[i])          # 将命令字符传入
        else:
            command_list.append(temp)
            temp = ""                       # 将分割好的字符数组传入命令
    return command_list                      # 传回命令列表

def run(command:list) -> str:
    '''
    执行命令的函数
    '''
    PATH = ".\\bin\\bin"                    # 执行命令时的path
    ran = None
    if (command[:1]==".\\" or command[:1]=="..") or (command[1]==":"):              # 判断是否为路径
        ran = subprocess.run(                       # 不加path
            command,
            shell=True,
            text=True
        )
    else:
        command.insert(0,PATH)                      # 添加path
    error = ran.stderr                          # 输出的错误
    out = ran.stdout                            # 输出的结果
    if ran.returncode == 0:                     # 是否正常结束
        return out
    else:
        return error
